<template>
    <div class="spinner-container">
      <div class="spinner"></div><p>Načítavam aplikáciu...</p>
    </div>
  </template>
  <style scoped>
  .spinner-container{display:flex;flex-direction:column;justify-content:center;align-items:center;height:100vh;}
  .spinner{border:4px solid rgba(0,0,0,0.1);width:36px;height:36px;border-radius:50%;border-left-color:#00dc82;animation:spin 1s ease infinite;}
  @keyframes spin{0%{transform:rotate(0deg)}100%{transform:rotate(360deg)}}
  </style>