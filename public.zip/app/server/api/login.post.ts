// app/server/api/login.post.ts
import type { User } from '~/types/user';

// Teraz máme zoznam používateľov
const MOCK_USERS: User[] = [
  {
    id: '1',
    name: 'Ján Vzorový',
    email: 'user@example.com',
    avatar: 'https://i.pravatar.cc/150?u=user@example.com',
    role: 'user', // Bežný používateľ
  },
  {
    id: '2',
    name: 'Alena Adminová',
    email: 'admin@example.com',
    avatar: 'https://i.pravatar.cc/150?u=admin@example.com',
    role: 'admin', // Administrátor
  }
];

export default defineEventHandler(async (event) => {
  const body = await readBody(event);
  await new Promise((resolve) => setTimeout(resolve, 500));

  // Nájdi používateľa podľa emailu a hesla
  const foundUser = MOCK_USERS.find(
    user => user.email === body.email && body.password === 'password'
  );

  if (foundUser) {
    return foundUser; // Vrátime nájdeného používateľa
  } else {
    throw createError({
      statusCode: 401,
      statusMessage: 'Nesprávne meno alebo heslo.',
    });
  }
});