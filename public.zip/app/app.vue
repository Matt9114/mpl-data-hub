<template>
  <div>
    <div v-if="isAppLoading">
      <LoadingSpinner />
    </div>

    <div v-else>
      <NuxtLayout>
        <NuxtPage />
      </NuxtLayout>
    </div>

    <div v-if="isPageLoading" class="page-loading-overlay">
      <LoadingSpinner />
    </div>
  </div>
</template>

<script setup lang="ts">
// Toast CSS (globálne)
import 'vue-toastification/dist/index.css'

const isAppLoading = useIsAppLoading()
const isPageLoading = useIsPageLoading()
</script>

<style>
.page-loading-overlay {
  position: fixed; inset: 0;
  display: flex; justify-content: center; align-items: center;
  background-color: rgba(255,255,255,.7);
  z-index: 9999;
  backdrop-filter: blur(4px);
}

/* Uisti sa, že toast-y sú nad overlayom */
.vue-toastification__container {
  z-index: 10000;
}
</style>
